enum DeviceType {
  androidPhone,
  androidTab,
  iPhone,
  iPad,
  iMac,
  macbook,
  otherMacintosh,
  winDesktop,
  winLaptop,
}
