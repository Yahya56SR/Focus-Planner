enum Difficulty {
  practice,
  easy,
  normal,
  hard,
  extreme,
  ultraHard,
}
